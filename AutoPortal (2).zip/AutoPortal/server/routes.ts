import type { Express } from "express";
import { createServer, type Server } from "http";

const EXTERNAL_API_BASE = "https://elimyandi-az.onrender.com/elimyandi";

export async function registerRoutes(app: Express): Promise<Server> {
  // Proxy routes for external API to handle CORS
  
  // Get all profiles with shared cars data for filters
  app.get("/api/profiles", async (req, res) => {
    try {
      // Fetch both profiles and cars data
      const [profilesResponse, carsResponse] = await Promise.all([
        fetch(`${EXTERNAL_API_BASE}/profiles`),
        fetch(`${EXTERNAL_API_BASE}/cars`)
      ]);

      if (!profilesResponse.ok) {
        throw new Error(`Failed to fetch profiles: ${profilesResponse.statusText}`);
      }
      if (!carsResponse.ok) {
        throw new Error(`Failed to fetch cars: ${carsResponse.statusText}`);
      }

      const profiles = await profilesResponse.json();
      const cars = await carsResponse.json();

      // Extract unique brands and their models from cars data
      const sharedCars: Record<string, string[]> = {};
      
      cars.forEach((car: any) => {
        if (car.brand && car.model) {
          if (!sharedCars[car.brand]) {
            sharedCars[car.brand] = [];
          }
          if (!sharedCars[car.brand].includes(car.model)) {
            sharedCars[car.brand].push(car.model);
          }
        }
      });

      // Sort brands and models alphabetically
      Object.keys(sharedCars).sort().forEach(brand => {
        sharedCars[brand].sort();
      });

      // Return profiles with sharedCars data
      res.json({
        profiles,
        sharedCars
      });
    } catch (error) {
      console.error("Error fetching profiles:", error);
      res.status(500).json({ error: "Failed to fetch profiles" });
    }
  });

  // Get all cars
  app.get("/api/cars", async (req, res) => {
    try {
      const response = await fetch(`${EXTERNAL_API_BASE}/cars`);
      if (!response.ok) {
        throw new Error(`Failed to fetch cars: ${response.statusText}`);
      }
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Error fetching cars:", error);
      res.status(500).json({ error: "Failed to fetch cars" });
    }
  });

  // Get cars by profile with profile-specific sharedCars data
  app.get("/api/cars/profiles/:profileId", async (req, res) => {
    try {
      const { profileId } = req.params;
      const response = await fetch(`${EXTERNAL_API_BASE}/cars/profiles/${profileId}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch cars for profile ${profileId}: ${response.statusText}`);
      }
      const cars = await response.json();

      // Extract unique brands and models from this profile's cars
      const sharedCars: Record<string, string[]> = {};
      
      cars.forEach((car: any) => {
        if (car.brand && car.model) {
          if (!sharedCars[car.brand]) {
            sharedCars[car.brand] = [];
          }
          if (!sharedCars[car.brand].includes(car.model)) {
            sharedCars[car.brand].push(car.model);
          }
        }
      });

      // Sort brands and models alphabetically
      Object.keys(sharedCars).sort().forEach(brand => {
        sharedCars[brand].sort();
      });

      res.json({
        cars,
        sharedCars
      });
    } catch (error) {
      console.error("Error fetching cars by profile:", error);
      res.status(500).json({ error: "Failed to fetch cars by profile" });
    }
  });

  // Search cars
  app.get("/api/cars/search", async (req, res) => {
    try {
      const searchParams = new URLSearchParams();
      
      // Forward all query parameters to the external API
      Object.entries(req.query).forEach(([key, value]) => {
        if (value !== null && value !== undefined && value !== '') {
          searchParams.append(key, value.toString());
        }
      });
      
      const response = await fetch(`${EXTERNAL_API_BASE}/cars/search?${searchParams.toString()}`);
      if (!response.ok) {
        throw new Error(`Failed to search cars: ${response.statusText}`);
      }
      const data = await response.json();
      res.json(data);
    } catch (error) {
      console.error("Error searching cars:", error);
      res.status(500).json({ error: "Failed to search cars" });
    }
  });
  
  const httpServer = createServer(app);

  return httpServer;
}
