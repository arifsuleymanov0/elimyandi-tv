// Storage interface for future extensions
// Currently using external API, so storage is not needed

export interface IStorage {
  // Placeholder for future storage methods
}

// Export placeholder for future use
