import { Profile, Car, SearchFilters, ProfilesResponse } from "./types";

// Use local backend proxy routes
const API_BASE = "/api";

export async function fetchProfiles(): Promise<ProfilesResponse> {
  const response = await fetch(`${API_BASE}/profiles`);
  if (!response.ok) {
    throw new Error(`Failed to fetch profiles: ${response.statusText}`);
  }
  return response.json();
}

export async function fetchCars(): Promise<Car[]> {
  const response = await fetch(`${API_BASE}/cars`);
  if (!response.ok) {
    throw new Error(`Failed to fetch cars: ${response.statusText}`);
  }
  return response.json();
}

export async function fetchCarsByProfile(profileId: number): Promise<Car[]> {
  const response = await fetch(`${API_BASE}/cars/profiles/${profileId}`);
  if (!response.ok) {
    throw new Error(`Failed to fetch cars for profile ${profileId}: ${response.statusText}`);
  }
  return response.json();
}

export async function searchCars(filters: SearchFilters): Promise<Car[]> {
  const params = new URLSearchParams();
  
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== null && value !== undefined && value !== '') {
      params.append(key, value.toString());
    }
  });
  
  const response = await fetch(`${API_BASE}/cars/search?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Failed to search cars: ${response.statusText}`);
  }
  return response.json();
}
