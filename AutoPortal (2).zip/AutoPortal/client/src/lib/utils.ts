import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { RANDOM_CAR_IMAGES, RANDOM_PROFILE_IMAGES } from "./types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function processImage(base64Data: string, isProfile = false): string {
  try {
    // Check if base64Data is valid and not just a placeholder
    if (!base64Data || 
        base64Data === 'base64' || 
        base64Data.length < 50 ||
        !base64Data.startsWith('data:image')) {
      throw new Error('Invalid base64 data');
    }
    return base64Data;
  } catch (error) {
    // Return random fallback image
    const randomImages = isProfile ? RANDOM_PROFILE_IMAGES : RANDOM_CAR_IMAGES;
    const randomIndex = Math.floor(Math.random() * randomImages.length);
    return randomImages[randomIndex];
  }
}

export function formatPrice(price: number, currency: string): string {
  return new Intl.NumberFormat('en-US').format(price) + ' ' + currency;
}

export function formatEngine(engine: string, fuelType: string): string {
  return `${engine}L ${fuelType === 'PETROL' ? 'Benzin' : fuelType === 'DIESEL' ? 'Dizel' : fuelType}`;
}
