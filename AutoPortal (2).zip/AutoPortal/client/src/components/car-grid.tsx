import { useQuery } from "@tanstack/react-query";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";
import CarCard from "./car-card";
import { fetchCars, fetchCarsByProfile, searchCars } from "@/lib/api";
import { SearchFilters } from "@/lib/types";

interface CarGridProps {
  filters?: SearchFilters;
  profileId?: number;
}

export default function CarGrid({ filters, profileId }: CarGridProps) {
  const { data: cars, isLoading, error } = useQuery({
    queryKey: profileId 
      ? ["/api/cars/profiles", profileId, filters] 
      : filters 
        ? ["/api/cars/search", filters]
        : ["/api/cars"],
    queryFn: () => {
      if (profileId && !filters) {
        return fetchCarsByProfile(profileId);
      } else if (filters && Object.keys(filters).length > 0) {
        return searchCars(filters);
      } else {
        return fetchCars();
      }
    },
  });

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6" data-testid="car-grid-loading">
        {Array.from({ length: 8 }).map((_, index) => (
          <div key={index} className="space-y-3">
            <Skeleton className="h-48 w-full rounded-xl" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
            <div className="space-y-2">
              <Skeleton className="h-3 w-full" />
              <Skeleton className="h-3 w-full" />
              <Skeleton className="h-3 w-2/3" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <Alert className="max-w-md mx-auto" data-testid="car-grid-error">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Avtomobillər yüklənərkən xəta baş verdi. Zəhmət olmasa yenidən cəhd edin.
        </AlertDescription>
      </Alert>
    );
  }

  if (!cars || cars.length === 0) {
    return (
      <div className="text-center py-12" data-testid="car-grid-empty">
        <p className="text-gray-500 text-lg">Heç bir avtomobil tapılmadı.</p>
        <p className="text-gray-400 text-sm mt-2">Axtarış meyarlarınızı dəyişdirin və yenidən cəhd edin.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6" data-testid="car-grid">
      {cars.map((car) => (
        <CarCard key={car.id} car={car} />
      ))}
    </div>
  );
}
