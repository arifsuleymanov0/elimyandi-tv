import { Car } from "lucide-react";

export default function Header() {
  return (
    <header className="bg-white shadow-sm border-b" data-testid="header">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="text-2xl font-bold text-brand-blue flex items-center" data-testid="logo">
            <Car className="mr-2" />
            ELİMYANDI
          </div>
          <nav className="hidden md:flex space-x-6" data-testid="navigation">
            <a href="#" className="text-gray-600 hover:text-brand-blue" data-testid="nav-home">Ana Səhifə</a>
            <a href="#" className="text-gray-600 hover:text-brand-blue" data-testid="nav-cars">Avtomobillər</a>
            <a href="#" className="text-gray-600 hover:text-brand-blue" data-testid="nav-about">Haqqımızda</a>
            <a href="#" className="text-gray-600 hover:text-brand-blue" data-testid="nav-contact">Əlaqə</a>
          </nav>
        </div>
      </div>
    </header>
  );
}
