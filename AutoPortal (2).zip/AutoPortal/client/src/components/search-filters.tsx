import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import { SearchFilters, Profile } from "@/lib/types";
import { fetchProfiles } from "@/lib/api";

interface SearchFiltersProps {
  onSearch: (filters: SearchFilters) => void;
  loading?: boolean;
  profileId?: number;
}

export default function SearchFiltersComponent({ onSearch, loading, profileId }: SearchFiltersProps) {
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [credit, setCredit] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [minYear, setMinYear] = useState("");
  const [maxYear, setMaxYear] = useState("");

  // Fetch data based on context (profile or global)
  const { data: profilesData } = useQuery({
    queryKey: ["/api/profiles"],
    queryFn: fetchProfiles,
    enabled: !profileId, // Only fetch if not on a profile page
  });

  const { data: profileCarsData } = useQuery({
    queryKey: ["/api/cars/profiles", profileId],
    queryFn: () => fetch(`/api/cars/profiles/${profileId}`).then(res => res.json()),
    enabled: !!profileId, // Only fetch if on a profile page
  });

  // Get brands and models based on context (profile page or main page)
  const getBrandsAndModels = () => {
    if (profileId) {
      // On profile page - use profile-specific sharedCars
      if (!profileCarsData) return { brands: [], models: [] };
      const sharedCars = profileCarsData.sharedCars || {};
      return {
        brands: Object.keys(sharedCars),
        models: brand && brand !== "ALL" ? (sharedCars[brand] || []) : []
      };
    } else {
      // On main page - use global sharedCars (handle nested API structure)
      if (!profilesData) return { brands: [], models: [] };
      const sharedCars = profilesData.sharedCars || {};
      return {
        brands: Object.keys(sharedCars),
        models: brand && brand !== "ALL" ? (sharedCars[brand] || []) : []
      };
    }
  };

  const { brands, models } = getBrandsAndModels();

  // Reset model when brand changes
  useEffect(() => {
    if (brand === "ALL" || !brand) {
      setModel("");
    }
  }, [brand]);

  const handleSearch = () => {
    const filters: SearchFilters = {
      ...(profileId && { profileId }),
      ...(brand && brand !== "ALL" && { brand }),
      ...(model && model !== "ALL" && { model }),
      ...(credit && credit !== "ALL" && { isValidForLoan: credit === "true" }),
      ...(minPrice && { minPrice: parseInt(minPrice) }),
      ...(maxPrice && { maxPrice: parseInt(maxPrice) }),
      ...(minYear && { minYear: parseInt(minYear) }),
      ...(maxYear && { maxYear: parseInt(maxYear) }),
    };
    onSearch(filters);
  };

  return (
    <section className="bg-white border-b shadow-sm" data-testid="search-filters">
      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {/* Brand Filter */}
          <div>
            <Label htmlFor="brand-filter" className="block text-sm font-medium text-gray-700 mb-2">
              Marka
            </Label>
            <Select value={brand} onValueChange={setBrand}>
              <SelectTrigger data-testid="select-brand">
                <SelectValue placeholder="Bütün markalar" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">Bütün markalar</SelectItem>
                {brands.map((brandName) => (
                  <SelectItem key={brandName} value={brandName}>{brandName}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Model Filter */}
          <div>
            <Label htmlFor="model-filter" className="block text-sm font-medium text-gray-700 mb-2">
              Model
            </Label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger data-testid="select-model">
                <SelectValue placeholder="Bütün modellər" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">Bütün modellər</SelectItem>
                {models.map((modelName: string) => (
                  <SelectItem key={modelName} value={modelName}>{modelName}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Credit Filter */}
          <div>
            <Label htmlFor="credit-filter" className="block text-sm font-medium text-gray-700 mb-2">
              Kredit
            </Label>
            <Select value={credit} onValueChange={setCredit}>
              <SelectTrigger data-testid="select-credit">
                <SelectValue placeholder="Hamısı" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">Hamısı</SelectItem>
                <SelectItem value="true">Kreditə yararlı</SelectItem>
                <SelectItem value="false">Kreditə yararlı deyil</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Min Price */}
          <div>
            <Label htmlFor="min-price" className="block text-sm font-medium text-gray-700 mb-2">
              Min Qiymət (AZN)
            </Label>
            <Input
              id="min-price"
              type="number"
              placeholder="0"
              value={minPrice}
              onChange={(e) => setMinPrice(e.target.value)}
              data-testid="input-min-price"
            />
          </div>

          {/* Max Price */}
          <div>
            <Label htmlFor="max-price" className="block text-sm font-medium text-gray-700 mb-2">
              Max Qiymət (AZN)
            </Label>
            <Input
              id="max-price"
              type="number"
              placeholder="200000"
              value={maxPrice}
              onChange={(e) => setMaxPrice(e.target.value)}
              data-testid="input-max-price"
            />
          </div>

          {/* Year Range */}
          <div className="md:col-span-2 lg:col-span-1">
            <Label className="block text-sm font-medium text-gray-700 mb-2">İl aralığı</Label>
            <div className="flex space-x-2">
              <Input
                type="number"
                placeholder="2010"
                min="2000"
                max="2025"
                value={minYear}
                onChange={(e) => setMinYear(e.target.value)}
                data-testid="input-min-year"
              />
              <Input
                type="number"
                placeholder="2025"
                min="2000"
                max="2025"
                value={maxYear}
                onChange={(e) => setMaxYear(e.target.value)}
                data-testid="input-max-year"
              />
            </div>
          </div>
        </div>

        {/* Search Button */}
        <div className="mt-4">
          <Button 
            onClick={handleSearch}
            disabled={loading}
            className="bg-brand-blue hover:bg-blue-700 text-white"
            data-testid="button-search"
          >
            <Search className="mr-2 h-4 w-4" />
            Axtar
          </Button>
        </div>
      </div>
    </section>
  );
}
