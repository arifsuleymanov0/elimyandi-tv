import { useQuery } from "@tanstack/react-query";
import { ArrowRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { fetchProfiles } from "@/lib/api";
import { processImage } from "@/lib/utils";
import { Link } from "wouter";

export default function ProfileSection() {
  const { data: profilesData, isLoading, error } = useQuery({
    queryKey: ["/api/profiles"],
    queryFn: fetchProfiles,
  });

  // Handle API response structure - external API returns nested profiles
  const profiles = profilesData?.profiles?.profiles || (Array.isArray(profilesData?.profiles) ? profilesData?.profiles : []);

  if (isLoading) {
    return (
      <section className="bg-white py-6" data-testid="profile-section-loading">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between mb-4">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-6 w-32" />
          </div>
          <div className="flex space-x-4 overflow-x-auto scrollbar-hide pb-2">
            {Array.from({ length: 6 }).map((_, index) => (
              <div key={index} className="flex-shrink-0 text-center">
                <Skeleton className="w-16 h-16 rounded-full mx-auto mb-2" />
                <Skeleton className="h-4 w-20 mx-auto mb-1" />
                <Skeleton className="h-3 w-16 mx-auto" />
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="bg-white py-6" data-testid="profile-section-error">
        <div className="container mx-auto px-4">
          <Alert className="max-w-md mx-auto">
            <AlertDescription>
              Populyar satıcılar yüklənərkən xəta baş verdi.
            </AlertDescription>
          </Alert>
        </div>
      </section>
    );
  }

  if (!profiles || !Array.isArray(profiles) || profiles.length === 0) {
    return null;
  }

  return (
    <section className="bg-white py-6" data-testid="profile-section">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold text-gray-800">Populyar satıcılar</h2>
          <Link 
            href="/profiles" 
            className="text-brand-blue hover:text-blue-700 font-medium flex items-center" 
            data-testid="button-see-all-profiles"
          >
            Hamısını gör <ArrowRight className="ml-1 h-4 w-4" />
          </Link>
        </div>
        
        <div className="relative overflow-hidden">
          <div className="profiles-scroll flex space-x-4 pb-2">
            {profiles.concat(profiles).map((profile, index) => (
              <Link 
                key={`${profile.id}-${index}`} 
                href={`/profile/${profile.id}`}
                className="profile-card flex-shrink-0 text-center cursor-pointer hover:transform hover:scale-105 transition-all duration-200"
                data-testid={`profile-card-${profile.id}-${index}`}
              >
                <img 
                  src={processImage(profile.image || "", true)}
                  alt="Profile Avatar" 
                  className="w-24 h-24 rounded-full mx-auto mb-2 object-cover border-2 border-gray-200 hover:border-brand-blue transition-colors"
                  data-testid={`profile-image-${profile.id}`}
                />
                <p className="font-medium text-sm text-gray-800" data-testid={`profile-name-${profile.id}`}>{profile.name}</p>
                <p className="text-xs text-gray-500" data-testid={`profile-quantity-${profile.id}`}>{profile.quantity} elan</p>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
