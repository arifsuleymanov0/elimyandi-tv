import { Car, Phone, Mail } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-800 text-white py-12 mt-12" data-testid="footer">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="text-xl font-bold mb-4 flex items-center">
              <Car className="mr-2" />
              ELİMYANDI
            </div>
            <p className="text-gray-400">Azərbaycanda ən böyük avtomobil bazarı</p>
          </div>
          <div>
            <h3 className="font-semibold mb-4">Kateqoriyalar</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white">Yeni avtomobillər</a></li>
              <li><a href="#" className="hover:text-white">İstifadə edilmiş</a></li>
              <li><a href="#" className="hover:text-white">Kreditlə</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-4">Dəstək</h3>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-white">Yardım mərkəzi</a></li>
              <li><a href="#" className="hover:text-white">Əlaqə</a></li>
              <li><a href="#" className="hover:text-white">Şərtlər</a></li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold mb-4">Əlaqə</h3>
            <div className="space-y-2 text-gray-400">
              <p className="flex items-center"><Phone className="mr-2 w-4 h-4" />+994 12 123 45 67</p>
              <p className="flex items-center"><Mail className="mr-2 w-4 h-4" />info@elimyandi.az</p>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-gray-400">
          <p>&copy; 2024 ELİMYANDI. Bütün hüquqlar qorunur.</p>
        </div>
      </div>
    </footer>
  );
}
