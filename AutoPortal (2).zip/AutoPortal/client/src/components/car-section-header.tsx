import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { SearchFilters } from "@/lib/types";

interface CarSectionHeaderProps {
  onSortChange: (sortBy?: string, order?: string) => void;
  totalCars: number;
}

export default function CarSectionHeader({ onSortChange, totalCars }: CarSectionHeaderProps) {
  const [sortBy, setSortBy] = useState("");
  const [order, setOrder] = useState("");

  const handleSortByChange = (value: string) => {
    setSortBy(value);
    onSortChange(value === "ALL" ? undefined : value, order === "ALL" ? undefined : order);
  };

  const handleOrderChange = (value: string) => {
    setOrder(value);
    onSortChange(sortBy === "ALL" ? undefined : sortBy, value === "ALL" ? undefined : value);
  };

  return (
    <div className="flex items-center justify-between mb-6 bg-white p-4 rounded-lg shadow-sm" data-testid="car-section-header">
      <div className="flex items-center space-x-4">
        <h2 className="text-xl font-bold text-gray-800">Avtomobillər</h2>
        <span className="text-gray-600 bg-gray-100 px-3 py-1 rounded-full text-sm" data-testid="car-count">
          {totalCars} avtomobil
        </span>
      </div>
      
      <div className="flex items-center space-x-4">
        {/* Sort By */}
        <div className="flex items-center space-x-2">
          <Label htmlFor="sort-by" className="text-sm font-medium text-gray-700 whitespace-nowrap">
            Sıralama:
          </Label>
          <Select value={sortBy} onValueChange={handleSortByChange}>
            <SelectTrigger className="w-32" data-testid="select-sort-by">
              <SelectValue placeholder="Seçin" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Hamısı</SelectItem>
              <SelectItem value="price">Qiymət</SelectItem>
              <SelectItem value="year">İl</SelectItem>
              <SelectItem value="mileage">Yürüş</SelectItem>
              <SelectItem value="createdAt">Tarix</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Order */}
        <div className="flex items-center space-x-2">
          <Label htmlFor="order" className="text-sm font-medium text-gray-700 whitespace-nowrap">
            Sıra:
          </Label>
          <Select value={order} onValueChange={handleOrderChange}>
            <SelectTrigger className="w-24" data-testid="select-order">
              <SelectValue placeholder="Seçin" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">Hamısı</SelectItem>
              <SelectItem value="desc">Azalma</SelectItem>
              <SelectItem value="asc">Artma</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}