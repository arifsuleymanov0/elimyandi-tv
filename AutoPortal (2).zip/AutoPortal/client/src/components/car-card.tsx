import { CreditCard, Fuel, Calendar, Navigation, MapPin, Instagram, Music } from "lucide-react";
import { Car } from "@/lib/types";
import { processImage, formatPrice, formatEngine } from "@/lib/utils";

interface CarCardProps {
  car: Car;
}

export default function CarCard({ car }: CarCardProps) {
  const carImage = processImage(car.image);
  const profileImage = processImage(car.profileImage, true);

  const handleInstagramClick = () => {
    if (car.instagramUrl && car.instagramUrl !== 'www') {
      window.open(car.instagramUrl.startsWith('http') ? car.instagramUrl : `https://${car.instagramUrl}`, '_blank');
    }
  };

  const handleTiktokClick = () => {
    if (car.tiktokUrl && car.tiktokUrl !== 'www') {
      window.open(car.tiktokUrl.startsWith('http') ? car.tiktokUrl : `https://${car.tiktokUrl}`, '_blank');
    }
  };

  return (
    <div className="car-card bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden hover:-translate-y-1" data-testid={`car-card-${car.id}`}>
      <div className="relative">
        <img 
          src={carImage}
          alt={`${car.brand} ${car.model}`}
          className="w-full h-48 object-cover"
          data-testid={`car-image-${car.id}`}
        />
        {car.isValidForLoan && (
          <div className="absolute top-3 left-3 bg-brand-green text-white px-2 py-1 rounded-md text-xs font-semibold flex items-center" data-testid={`credit-badge-${car.id}`}>
            <CreditCard className="mr-1 h-3 w-3" />
            Kredit
          </div>
        )}
      </div>
      
      <div className="p-4">
        {/* Brand and Price Row */}
        <div className="flex items-center justify-between mb-1">
          <h3 className="font-bold text-lg text-gray-800" data-testid={`car-brand-${car.id}`}>{car.brand}</h3>
          <p className="font-bold text-lg text-price-red" data-testid={`car-price-${car.id}`}>{formatPrice(car.price, car.currency)}</p>
        </div>
        
        {/* Model Row */}
        <p className="text-gray-600 text-base mb-3" data-testid={`car-model-${car.id}`}>{car.model}</p>
        
        <div className="flex justify-between">
          {/* Specifications Column */}
          <div className="space-y-1 text-sm text-gray-600 flex-1">
            <div className="flex items-center">
              <Fuel className="mr-2 text-gray-400 w-4 h-4" />
              <span data-testid={`car-engine-${car.id}`}>{formatEngine(car.engine, car.fuelType)}</span>
            </div>
            <div className="flex items-center">
              <Calendar className="mr-2 text-gray-400 w-4 h-4" />
              <span data-testid={`car-year-${car.id}`}>{car.year}</span>
            </div>
            <div className="flex items-center">
              <Navigation className="mr-2 text-gray-400 w-4 h-4" />
              <span data-testid={`car-mileage-${car.id}`}>{car.mileage}</span>
            </div>
          </div>
          
          {/* Social Media Icons */}
          <div className="flex flex-col space-y-2 ml-4">
            <button
              onClick={handleInstagramClick}
              className="text-pink-500 hover:text-pink-600 transition-colors"
              data-testid={`instagram-link-${car.id}`}
            >
              <Instagram className="w-8 h-8" />
            </button>
            <button
              onClick={handleTiktokClick}
              className="text-gray-800 hover:text-gray-900 transition-colors"
              data-testid={`tiktok-link-${car.id}`}
            >
              <Music className="w-8 h-8" />
            </button>
          </div>
        </div>
        
        {/* Credit Info */}
        <div className={`mt-3 p-2 rounded-lg ${car.initialPayment ? 'bg-green-50' : 'bg-red-50'}`}>
          <p className={`text-sm font-medium ${car.initialPayment ? 'text-brand-green' : 'text-red-600'}`} data-testid={`credit-info-${car.id}`}>
            {car.initialPayment ? `İlkin ödəniş ${formatPrice(car.initialPayment, car.currency)}` : 'Kreditə yararlı deyil'}
          </p>
        </div>
        
        {/* Location */}
        <div className="mt-3 flex items-center text-sm text-gray-500">
          <MapPin className="mr-1 w-4 h-4" />
          <span data-testid={`car-location-${car.id}`}>Bakı</span>
        </div>
        
        {/* Seller Info */}
        <div className="mt-3 pt-3 border-t border-gray-200 flex items-center justify-between">
          <div className="flex items-center">
            <img 
              src={profileImage}
              alt="Profile" 
              className="w-6 h-6 rounded-full mr-2"
              data-testid={`seller-image-${car.id}`}
            />
            <span className="text-sm font-medium text-gray-700" data-testid={`seller-name-${car.id}`}>{car.profileName}</span>
          </div>
          <span className="text-xs text-gray-500" data-testid={`published-time-${car.id}`}>{car.publishedAtString}</span>
        </div>
      </div>
    </div>
  );
}
