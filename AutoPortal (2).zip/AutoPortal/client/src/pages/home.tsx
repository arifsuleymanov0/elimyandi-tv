import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/header";
import Footer from "@/components/footer";
import SearchFilters from "@/components/search-filters";
import ProfileSection from "@/components/profile-section";
import CarGrid from "@/components/car-grid";
import CarSectionHeader from "@/components/car-section-header";
import { SearchFilters as SearchFiltersType } from "@/lib/types";
import { fetchCars, searchCars } from "@/lib/api";

export default function Home() {
  const [filters, setFilters] = useState<SearchFiltersType>({});

  const handleSearch = (newFilters: SearchFiltersType) => {
    setFilters(newFilters);
  };

  const handleSortChange = (sortBy?: string, order?: string) => {
    const newFilters = { ...filters };
    if (sortBy) {
      newFilters.sortBy = sortBy as "price" | "year" | "mileage" | "createdAt";
    } else {
      delete newFilters.sortBy;
    }
    if (order) {
      newFilters.order = order as "asc" | "desc";
    } else {
      delete newFilters.order;
    }
    setFilters(newFilters);
  };

  // Get car count for display
  const { data: cars } = useQuery({
    queryKey: Object.keys(filters).length > 0 ? ["/api/cars/search", filters] : ["/api/cars"],
    queryFn: () => Object.keys(filters).length > 0 ? searchCars(filters) : fetchCars(),
  });
  const totalCars = cars?.length || 0;

  return (
    <div className="min-h-screen bg-gray-50" data-testid="home-page">
      <Header />
      <SearchFilters onSearch={handleSearch} />
      <ProfileSection />
      
      <main className="container mx-auto px-4 py-6">
        <CarSectionHeader onSortChange={handleSortChange} totalCars={totalCars} />
        <CarGrid filters={filters} />
      </main>
      
      <Footer />
    </div>
  );
}
