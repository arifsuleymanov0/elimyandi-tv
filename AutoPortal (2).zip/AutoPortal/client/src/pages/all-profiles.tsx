import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Search, User } from "lucide-react";
import { Link } from "wouter";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { fetchProfiles } from "@/lib/api";
import { processImage } from "@/lib/utils";
import { Profile } from "@/lib/types";

export default function AllProfilesPage() {
  const [searchQuery, setSearchQuery] = useState("");

  const { data: profilesData, isLoading, error } = useQuery({
    queryKey: ["/api/profiles"],
    queryFn: fetchProfiles,
  });

  // Handle API response structure - external API returns nested profiles
  const profiles = profilesData?.profiles?.profiles || (Array.isArray(profilesData?.profiles) ? profilesData?.profiles : []);

  // Filter profiles by search query
  const filteredProfiles = profiles.filter((profile: Profile) =>
    profile.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50" data-testid="all-profiles-loading">
        <Header />
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center space-x-4 mb-6">
            <Skeleton className="h-6 w-6" />
            <Skeleton className="h-8 w-48" />
          </div>
          <Skeleton className="h-10 w-full max-w-md mb-6" />
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {Array.from({ length: 8 }).map((_, index) => (
              <div key={index} className="bg-white rounded-xl p-6 shadow-sm">
                <Skeleton className="w-32 h-32 rounded-full mx-auto mb-4" />
                <Skeleton className="h-6 w-24 mx-auto mb-2" />
                <Skeleton className="h-4 w-16 mx-auto" />
              </div>
            ))}
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50" data-testid="all-profiles-error">
        <Header />
        <div className="container mx-auto px-4 py-6">
          <Alert className="max-w-md mx-auto">
            <AlertDescription>
              Profillər yüklənərkən xəta baş verdi.
            </AlertDescription>
          </Alert>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" data-testid="all-profiles-page">
      <Header />
      
      <div className="container mx-auto px-4 py-6">
        {/* Back Button and Title */}
        <div className="flex items-center space-x-4 mb-6">
          <Link href="/" className="text-brand-blue hover:text-blue-700" data-testid="back-to-home">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-800">Bütün Satıcılar</h1>
        </div>

        {/* Search Field */}
        <div className="relative mb-6 max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            type="text"
            placeholder="Satıcı adına görə axtarış..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
            data-testid="search-profiles-input"
          />
        </div>

        {/* Profiles Grid */}
        {filteredProfiles.length === 0 ? (
          <div className="text-center py-12">
            <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {searchQuery ? "Heç bir satıcı tapılmadı" : "Satıcı tapılmadı"}
            </h3>
            <p className="text-gray-500">
              {searchQuery ? "Axtarış kriteriyalarını dəyişdirməyi sınayın." : "Hazırda heç bir satıcı mövcud deyil."}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {filteredProfiles.map((profile: Profile) => (
              <Link
                key={profile.id}
                href={`/profile/${profile.id}`}
                className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-all duration-200 hover:transform hover:scale-105 cursor-pointer"
                data-testid={`profile-card-large-${profile.id}`}
              >
                <div className="text-center">
                  {/* Large Profile Image - 2x size */}
                  <img 
                    src={processImage(profile.image || "", true)}
                    alt={profile.name}
                    className="w-32 h-32 rounded-full object-cover border-4 border-brand-blue mx-auto mb-4"
                    data-testid={`profile-avatar-large-${profile.id}`}
                  />
                  
                  {/* Profile Name */}
                  <h3 className="text-lg font-bold text-gray-800 mb-2" data-testid={`profile-name-${profile.id}`}>
                    {profile.name}
                  </h3>
                  
                  {/* Quantity */}
                  <p className="text-gray-600" data-testid={`profile-quantity-${profile.id}`}>
                    {profile.quantity ? `${profile.quantity} elan` : "Elan yoxdur"}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        )}

        {/* Results Count */}
        {searchQuery && (
          <div className="mt-6 text-center text-gray-600">
            <p data-testid="search-results-count">
              {filteredProfiles.length} satıcı tapıldı "{searchQuery}" üçün
            </p>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}