import { useState } from "react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import Header from "@/components/header";
import Footer from "@/components/footer";
import SearchFilters from "@/components/search-filters";
import CarGrid from "@/components/car-grid";
import CarSectionHeader from "@/components/car-section-header";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { fetchProfiles, fetchCarsByProfile, searchCars } from "@/lib/api";
import { processImage } from "@/lib/utils";
import { SearchFilters as SearchFiltersType } from "@/lib/types";

export default function ProfilePage() {
  const { id } = useParams();
  const profileId = parseInt(id || "0");
  const [filters, setFilters] = useState<SearchFiltersType>({ profileId });

  const { data: profilesData, isLoading, error } = useQuery({
    queryKey: ["/api/profiles"],
    queryFn: fetchProfiles,
  });

  // Handle API response structure - external API returns nested profiles
  const profilesArray = profilesData?.profiles?.profiles || (Array.isArray(profilesData?.profiles) ? profilesData?.profiles : []);
  const profile = profilesArray.find((p: any) => p.id === profileId);

  const handleSearch = (newFilters: SearchFiltersType) => {
    setFilters({ ...newFilters, profileId });
  };

  const handleSortChange = (sortBy?: string, order?: string) => {
    const newFilters = { ...filters };
    if (sortBy) {
      newFilters.sortBy = sortBy as "price" | "year" | "mileage" | "createdAt";
    } else {
      delete newFilters.sortBy;
    }
    if (order) {
      newFilters.order = order as "asc" | "desc";
    } else {
      delete newFilters.order;
    }
    setFilters(newFilters);
  };

  // Get car count for display
  const { data: cars } = useQuery({
    queryKey: ["/api/cars/profiles", profileId, filters],
    queryFn: () => {
      if (Object.keys(filters).length > 1) { // more than just profileId
        return searchCars(filters);
      } else {
        return fetchCarsByProfile(profileId);
      }
    },
    enabled: !!profileId,
  });
  const totalCars = cars?.length || 0;

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50" data-testid="profile-page-loading">
        <Header />
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center space-x-4 mb-6">
            <Skeleton className="h-6 w-6" />
            <Skeleton className="h-8 w-48" />
          </div>
          <div className="bg-white rounded-xl p-6 mb-6">
            <div className="flex items-center space-x-4">
              <Skeleton className="w-20 h-20 rounded-full" />
              <div className="space-y-2">
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-24" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-gray-50" data-testid="profile-page-error">
        <Header />
        <div className="container mx-auto px-4 py-6">
          <Alert className="max-w-md mx-auto">
            <AlertDescription>
              Profil tapılmadı və ya yüklənərkən xəta baş verdi.
            </AlertDescription>
          </Alert>
          <div className="text-center mt-6">
            <Link href="/">
              <Button variant="outline">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Ana səhifəyə qayıt
              </Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50" data-testid="profile-page">
      <Header />
      <SearchFilters onSearch={handleSearch} profileId={profileId} />
      
      <main className="container mx-auto px-4 py-6">
        {/* Back Button */}
        <div className="mb-6">
          <Link href="/">
            <Button variant="outline" data-testid="back-button">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Ana səhifəyə qayıt
            </Button>
          </Link>
        </div>

        {/* Profile Header */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-6" data-testid="profile-header">
          <div className="flex items-center space-x-4">
            <img 
              src={processImage(profile.image || "", true)}
              alt={profile.name}
              className="w-20 h-20 rounded-full object-cover border-4 border-brand-blue"
              data-testid="profile-avatar"
            />
            <div>
              <h1 className="text-2xl font-bold text-gray-800" data-testid="profile-name">
                {profile.name}
              </h1>
              <p className="text-gray-600" data-testid="profile-quantity">
                {profile.quantity} elan
              </p>
              {profile.description !== 'www' && (
                <p className="text-gray-500 mt-1" data-testid="profile-description">
                  {profile.description}
                </p>
              )}
            </div>
          </div>
        </div>

        <CarSectionHeader onSortChange={handleSortChange} totalCars={totalCars} />
        <CarGrid filters={filters} profileId={profileId} />
      </main>
      
      <Footer />
    </div>
  );
}
