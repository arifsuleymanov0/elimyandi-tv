import { z } from "zod";

export const profileSchema = z.object({
  id: z.number(),
  name: z.string(),
  phone: z.string(),
  instagramUrl: z.string(),
  tiktokUrl: z.string(),
  description: z.string().optional(),
  image: z.string().nullable(),
  quantity: z.number().nullable(),
  sharedCars: z.record(z.array(z.string())),
});

export const carSchema = z.object({
  id: z.number(),
  brand: z.string(),
  model: z.string(),
  year: z.number(),
  price: z.number(),
  currency: z.string(),
  color: z.string(),
  engine: z.string(),
  fuelType: z.string(),
  gearBox: z.string(),
  mileage: z.string(),
  initialPayment: z.number().nullable(),
  isValidForLoan: z.boolean(),
  instagramUrl: z.string(),
  tiktokUrl: z.string(),
  profileName: z.string(),
  profileImage: z.string(),
  image: z.string(),
  publishedAtString: z.string(),
});

export const searchFiltersSchema = z.object({
  profileId: z.number().optional(),
  brand: z.string().optional(),
  model: z.string().optional(),
  isValidForLoan: z.boolean().optional(),
  minPrice: z.number().optional(),
  maxPrice: z.number().optional(),
  minYear: z.number().optional(),
  maxYear: z.number().optional(),
  sortBy: z.enum(["price", "year", "mileage", "createdAt"]).optional(),
  order: z.enum(["asc", "desc"]).optional(),
});

export const profilesResponseSchema = z.object({
  profiles: z.array(profileSchema),
  sharedCars: z.record(z.array(z.string())),
});

export type Profile = z.infer<typeof profileSchema>;
export type Car = z.infer<typeof carSchema>;
export type SearchFilters = z.infer<typeof searchFiltersSchema>;
export type ProfilesResponse = z.infer<typeof profilesResponseSchema>;
